<template>
  <div class="o sm:h-[calc(100vh-174px)] xl:h-[calc(100vh-186px)]">
    <div class="flex flex-col h-full gap-6 sm:gap-5 xl:grid xl:grid-cols-12">
      <div class="xl:col-span-3 w-full">
        <!-- Inbox Sidebar Start -->
        <EmailSidebar />
        <!-- Inbox Sidebar End -->
      </div>

      <!-- Inbox Mailbox Start -->
      <div class="xl:col-span-9 w-full">
        <div
          class="flex flex-col rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]"
        >
          <div
            class="flex flex-col justify-between border-b border-gray-200 dark:border-gray-800 sm:flex-row"
          >
            <div class="flex items-center justify-between w-full gap-3 px-4 py-4 sm:justify-normal">
              <button
                class="flex h-10 w-full max-w-10 items-center justify-center rounded-lg border border-gray-200 bg-white text-gray-700 hover:bg-gray-100 hover:text-gray-800 dark:border-gray-800 dark:bg-white/[0.03] dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200"
              >
                <svg
                  class="fill-current"
                  width="16"
                  height="16"
                  viewBox="0 0 16 16"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    d="M1.91634 7.99899C1.91612 8.19115 1.98928 8.38337 2.13583 8.53001L6.13316 12.5301C6.42595 12.8231 6.90082 12.8233 7.19382 12.5305C7.48681 12.2377 7.48698 11.7629 7.19419 11.4699L4.47396 8.74772L13.3339 8.74772C13.7481 8.74772 14.0839 8.41194 14.0839 7.99772C14.0839 7.58351 13.7481 7.24772 13.3339 7.24772L4.47834 7.24772L7.19417 4.53016C7.48697 4.23718 7.48682 3.7623 7.19383 3.4695C6.90085 3.1767 6.42597 3.17685 6.13317 3.46984L2.17075 7.43478C2.01476 7.57222 1.91634 7.77347 1.91634 7.99772C1.91634 7.99815 1.91634 7.99857 1.91634 7.99899Z"
                    fill="#"
                  />
                </svg>
              </button>

              <div class="flex items-center gap-3">
                <div class="flex">
                  <button
                    class="flex h-10 w-10 items-center justify-center text-gray-500 ring-1 ring-inset ring-gray-200 first:rounded-l-lg last:rounded-r-lg hover:bg-gray-100 hover:text-error-700 dark:bg-white/[0.03] dark:text-gray-400 dark:ring-gray-700 dark:hover:bg-white/[0.05] dark:hover:text-error-500"
                  >
                    <svg
                      class="fill-current"
                      width="20"
                      height="20"
                      viewBox="0 0 20 20"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        fill-rule="evenodd"
                        clip-rule="evenodd"
                        d="M6.54118 3.7915C6.54118 2.54886 7.54854 1.5415 8.79118 1.5415H11.2078C12.4505 1.5415 13.4578 2.54886 13.4578 3.7915V4.0415H15.6249H16.6658C17.08 4.0415 17.4158 4.37729 17.4158 4.7915C17.4158 5.20572 17.08 5.5415 16.6658 5.5415H16.3749V8.24638V13.2464V16.2082C16.3749 17.4508 15.3676 18.4582 14.1249 18.4582H5.87492C4.63228 18.4582 3.62492 17.4508 3.62492 16.2082V13.2464V8.24638V5.5415H3.33325C2.91904 5.5415 2.58325 5.20572 2.58325 4.7915C2.58325 4.37729 2.91904 4.0415 3.33325 4.0415H4.37492H6.54118V3.7915ZM14.8749 13.2464V8.24638V5.5415H13.4578H12.7078H7.29118H6.54118H5.12492V8.24638V13.2464V16.2082C5.12492 16.6224 5.46071 16.9582 5.87492 16.9582H14.1249C14.5391 16.9582 14.8749 16.6224 14.8749 16.2082V13.2464ZM8.04118 4.0415H11.9578V3.7915C11.9578 3.37729 11.6221 3.0415 11.2078 3.0415H8.79118C8.37696 3.0415 8.04118 3.37729 8.04118 3.7915V4.0415ZM8.33325 7.99984C8.74747 7.99984 9.08325 8.33562 9.08325 8.74984V13.7498C9.08325 14.1641 8.74747 14.4998 8.33325 14.4998C7.91904 14.4998 7.58325 14.1641 7.58325 13.7498V8.74984C7.58325 8.33562 7.91904 7.99984 8.33325 7.99984ZM12.4166 8.74984C12.4166 8.33562 12.0808 7.99984 11.6666 7.99984C11.2524 7.99984 10.9166 8.33562 10.9166 8.74984V13.7498C10.9166 14.1641 11.2524 14.4998 11.6666 14.4998C12.0808 14.4998 12.4166 14.1641 12.4166 13.7498V8.74984Z"
                        fill=""
                      />
                    </svg>
                  </button>
                  <button
                    class="-ml-px flex h-10 w-10 items-center justify-center text-gray-500 ring-1 ring-inset ring-gray-200 first:rounded-l-lg last:rounded-r-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-white/[0.03] dark:text-gray-400 dark:ring-gray-700 dark:hover:bg-white/[0.05] dark:hover:text-white"
                  >
                    <svg
                      class="fill-current"
                      width="20"
                      height="20"
                      viewBox="0 0 20 20"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        fill-rule="evenodd"
                        clip-rule="evenodd"
                        d="M3.04167 9.99984C3.04167 6.15686 6.15702 3.0415 10 3.0415C13.843 3.0415 16.9583 6.15686 16.9583 9.99984C16.9583 13.8428 13.843 16.9582 10 16.9582C6.15702 16.9582 3.04167 13.8428 3.04167 9.99984ZM10 1.5415C5.3286 1.5415 1.54167 5.32843 1.54167 9.99984C1.54167 14.6712 5.3286 18.4582 10 18.4582C14.6714 18.4582 18.4583 14.6712 18.4583 9.99984C18.4583 5.32843 14.6714 1.5415 10 1.5415ZM9.09926 6.27073C9.09926 6.76779 9.50221 7.17073 9.99926 7.17073H10.0003C10.4973 7.17073 10.9003 6.76779 10.9003 6.27073C10.9003 5.77368 10.4973 5.37073 10.0003 5.37073H9.99926C9.50221 5.37073 9.09926 5.77368 9.09926 6.27073ZM10.0001 14.601C9.58586 14.601 9.25008 14.2652 9.25008 13.851V9.12059C9.25008 8.70637 9.58586 8.37059 10.0001 8.37059C10.4143 8.37059 10.7501 8.70637 10.7501 9.12059V13.851C10.7501 14.2652 10.4143 14.601 10.0001 14.601Z"
                        fill="currentColor"
                      />
                    </svg>
                  </button>
                  <button
                    class="-ml-px flex h-10 w-10 items-center justify-center rounded-r-lg text-gray-500 ring-1 ring-inset ring-gray-200 first:rounded-l-lg last:rounded-r-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-white/[0.03] dark:text-gray-400 dark:ring-gray-700 dark:hover:bg-white/[0.05] dark:hover:text-white"
                  >
                    <svg
                      class="fill-current"
                      width="20"
                      height="20"
                      viewBox="0 0 20 20"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        fill-rule="evenodd"
                        clip-rule="evenodd"
                        d="M1.54163 4.8335C1.54163 3.59085 2.54899 2.5835 3.79163 2.5835H16.2083C17.4509 2.5835 18.4583 3.59085 18.4583 4.8335V5.16683C18.4583 5.96477 18.0429 6.66569 17.4166 7.06517V15.1668C17.4166 16.4095 16.4093 17.4168 15.1666 17.4168H4.83329C3.59065 17.4168 2.58329 16.4095 2.58329 15.1668V7.06517C1.95699 6.66568 1.54163 5.96476 1.54163 5.16683V4.8335ZM4.08329 7.41683H15.9166V15.1668C15.9166 15.581 15.5808 15.9168 15.1666 15.9168H4.83329C4.41908 15.9168 4.08329 15.581 4.08329 15.1668V7.41683ZM16.9583 5.16683C16.9583 5.58104 16.6225 5.91683 16.2083 5.91683H3.79163C3.37741 5.91683 3.04163 5.58104 3.04163 5.16683V4.8335C3.04163 4.41928 3.37741 4.0835 3.79163 4.0835H16.2083C16.6225 4.0835 16.9583 4.41928 16.9583 4.8335V5.16683ZM8.33329 9.04183C7.91908 9.04183 7.58329 9.37762 7.58329 9.79183C7.58329 10.206 7.91908 10.5418 8.33329 10.5418H11.6666C12.0808 10.5418 12.4166 10.206 12.4166 9.79183C12.4166 9.37762 12.0808 9.04183 11.6666 9.04183H8.33329Z"
                        fill=""
                      />
                    </svg>
                  </button>
                </div>

                <button
                  class="flex h-10 w-10 items-center justify-center rounded-lg border border-gray-200 bg-white text-gray-500 hover:bg-gray-50 hover:text-gray-700 dark:border-gray-800 dark:bg-white/[0.03] dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200"
                >
                  <svg
                    class="fill-current"
                    width="20"
                    height="20"
                    viewBox="0 0 20 20"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      fill-rule="evenodd"
                      clip-rule="evenodd"
                      d="M3.04166 7.06206V14.375C3.04166 14.6511 3.26551 14.875 3.54166 14.875H16.4583C16.7345 14.875 16.9583 14.6511 16.9583 14.375V7.06245L11.1443 11.1168C10.4569 11.5961 9.54364 11.5961 8.85629 11.1168L3.04166 7.06206ZM16.9583 5.19262C16.9583 5.19341 16.9583 5.1942 16.9583 5.19498V5.20026C16.9571 5.22216 16.946 5.24239 16.9279 5.25501L10.2863 9.88638C10.1144 10.0062 9.88611 10.0062 9.71428 9.88638L3.07246 5.25485C3.05333 5.24151 3.04193 5.21967 3.04192 5.19636C3.04191 5.15695 3.07385 5.125 3.11326 5.125H16.887C16.9252 5.125 16.9564 5.15494 16.9583 5.19262ZM18.4583 5.21428V14.375C18.4583 15.4796 17.5629 16.375 16.4583 16.375H3.54166C2.43709 16.375 1.54166 15.4796 1.54166 14.375V5.19498C1.54166 5.1852 1.54184 5.17546 1.54221 5.16577C1.55849 4.31209 2.25561 3.625 3.11326 3.625H16.887C17.7548 3.625 18.4583 4.32843 18.4584 5.19622C18.4584 5.20225 18.4584 5.20826 18.4583 5.21428Z"
                      fill=""
                    />
                  </svg>
                </button>
              </div>
            </div>

            <div
              class="flex items-center justify-between w-full gap-4 px-4 py-3 border-t border-gray-200 dark:border-gray-800 sm:justify-end sm:border-t-0 sm:py-5"
            >
              <p class="text-sm text-gray-500 dark:text-gray-400">4 of 120</p>
              <div class="flex items-center justify-end gap-2">
                <button
                  class="flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 bg-white text-gray-500 hover:bg-gray-50 dark:border-gray-800 dark:bg-white/[0.03] dark:text-gray-400 dark:hover:bg-white/[0.03]"
                >
                  <svg
                    class="stroke-current"
                    width="20"
                    height="20"
                    viewBox="0 0 20 20"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M12.7083 5L7.5 10.2083L12.7083 15.4167"
                      stroke=""
                      stroke-width="1.5"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                  </svg>
                </button>
                <button
                  class="flex h-8 w-8 items-center justify-center rounded-lg border border-gray-200 bg-white text-gray-500 hover:bg-gray-50 dark:border-gray-800 dark:bg-white/[0.03] dark:text-gray-400 dark:hover:bg-white/[0.03]"
                >
                  <svg
                    class="stroke-current"
                    width="20"
                    height="20"
                    viewBox="0 0 20 20"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      d="M7.29167 15.8335L12.5 10.6252L7.29167 5.41683"
                      stroke=""
                      stroke-width="1.5"
                      stroke-linecap="round"
                      stroke-linejoin="round"
                    />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          <!-- ====== Inbox Details Box Start -->
          <Simplebar class="max-h-[500px] 2xl:max-h-[790px]" data-simplebar-auto-hide="false">
            <div class="block p-5 overflow-auto custom-scrollbar xl:p-6">
              <div class="flex items-center gap-3 mb-9">
                <div class="w-12 h-12 overflow-hidden rounded-full">
                  <img src="/images/user/user-18.jpg" alt="user" />
                </div>

                <div>
                  <span class="mb-0.5 block text-sm font-medium text-gray-800 dark:text-white/90">
                    Contact For “Website Design”
                  </span>
                  <span class="block text-gray-500 text-theme-xs dark:text-gray-400">
                    Codescandy hello@example.com
                  </span>
                </div>
              </div>

              <div class="text-sm text-gray-500 mb-7 dark:text-gray-400">
                <p class="mb-4">Hello Dear Alexander,</p>

                <p class="mb-4">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent ut rutrum mi.
                  Aenean ac leo non justo suscipit consectetur. Nam vestibulum eleifend magna quis
                  porta. ipsum dolor sit amet, consectetur adipiscing elit. Praesent ut rutrum mi.
                  Aenean ac leo
                </p>

                <p class="mb-4">
                  Praesent ut rutrum mi. Aenean ac leo non justo suscipit consectetur. Nam
                  vestibulum eleifend magna quis porta.
                </p>

                <p class="mb-4">
                  Nullam tincidunt sodales diam, quis rhoncus dolor aliquet a. Nulla a rhoncus
                  lectus. In nunc neque, pellentesque non massa ornare, accumsan ornare massa.
                  odales diam, quis rhoncus dolor aliquet a. Nulla a rhoncus lectus. In nunc neque
                </p>

                <p class="mb-4">
                  Suspendisse semper vel turpis vitae aliquam. Aenean semper dui in consequat
                  ullamcorper.
                </p>

                <p class="mb-4">
                  Nullam tincidunt sodales diam, quis rhoncus dolor aliquet a. Nulla a rhoncus
                  lectus. In nunc neque, pellentesque non massa ornare, accumsan ornare massa.
                  sodales diam, quis rhoncus dolor aliquet a. Nulla a rhoncus lectus. In nunc neque
                </p>

                <p>
                  Praesent ut rutrum mi. Aenean ac leo non justo suscipit consectetur. Nam
                  vestibulum eleifend magna quis porta.
                </p>
              </div>

              <div class="p-3 rounded-xl bg-gray-50 dark:bg-gray-900 sm:p-4">
                <div class="flex items-center gap-2 mb-5">
                  <span class="text-gray-500 dark:text-gray-400">
                    <svg
                      class="fill-current"
                      width="20"
                      height="20"
                      viewBox="0 0 20 20"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        fill-rule="evenodd"
                        clip-rule="evenodd"
                        d="M10.6685 12.035C10.6685 12.044 10.6686 12.0529 10.6689 12.0617V13.4533C10.6689 13.8224 10.3697 14.1216 10.0006 14.1216C9.63155 14.1216 9.33235 13.8224 9.33235 13.4533V5.12807C9.33235 4.71385 8.99657 4.37807 8.58235 4.37807C8.16814 4.37807 7.83235 4.71385 7.83235 5.12807V13.4533C7.83235 14.6508 8.80313 15.6216 10.0006 15.6216C11.1981 15.6216 12.1689 14.6508 12.1689 13.4533V5.12807C12.1689 5.11803 12.1687 5.10804 12.1683 5.09811C12.1522 3.1311 10.5527 1.5415 8.58189 1.5415C6.60108 1.5415 4.99532 3.14727 4.99532 5.12807L4.99532 12.035C4.99532 12.0414 4.9954 12.0477 4.99556 12.0539V13.4533C4.99556 16.2174 7.2363 18.4582 10.0004 18.4582C12.7645 18.4582 15.0053 16.2174 15.0053 13.4533V7.96463C15.0053 7.55042 14.6695 7.21463 14.2553 7.21463C13.841 7.21463 13.5053 7.55042 13.5053 7.96463V13.4533C13.5053 15.389 11.9361 16.9582 10.0004 16.9582C8.06473 16.9582 6.49556 15.389 6.49556 13.4533V7.96463C6.49556 7.95832 6.49548 7.95202 6.49532 7.94574L6.49532 5.12807C6.49532 3.97569 7.42951 3.0415 8.58189 3.0415C9.73427 3.0415 10.6685 3.97569 10.6685 5.12807L10.6685 12.035Z"
                        fill=""
                      />
                    </svg>
                  </span>

                  <span class="text-sm text-gray-700 dark:text-gray-400"> 2 Attachments </span>
                </div>

                <div class="flex flex-col items-center gap-3 sm:flex-row">
                  <div
                    class="relative flex w-full cursor-pointer items-center gap-3 rounded-xl border border-gray-200 bg-white py-2.5 pl-3 pr-5 dark:border-gray-800 dark:bg-white/5 sm:w-auto"
                  >
                    <div class="w-full h-10 max-w-10">
                      <img src="/images/task/pdf.svg" alt="icon" />
                    </div>
                    <div>
                      <p class="text-sm font-medium text-gray-800 dark:text-white/90">
                        Guidelines.pdf
                      </p>
                      <span class="flex items-center gap-1.5">
                        <span class="text-gray-500 text-theme-xs dark:text-gray-400"> PDF </span>
                        <span class="inline-block w-1 h-1 bg-gray-400 rounded-full"></span>
                        <span class="text-gray-500 text-theme-xs dark:text-gray-400">
                          Download
                        </span>
                      </span>
                    </div>
                  </div>

                  <div
                    class="relative flex w-full cursor-pointer items-center gap-3 rounded-xl border border-gray-200 bg-white py-2.5 pl-3 pr-5 dark:border-gray-800 dark:bg-white/5 sm:w-auto"
                  >
                    <div class="w-full h-10 max-w-10">
                      <img src="/images/task/google-drive.svg" alt="icon" />
                    </div>
                    <div>
                      <p class="text-sm font-medium text-gray-800 dark:text-white/90">
                        Branding Assets
                      </p>
                      <span class="flex items-center gap-1.5">
                        <span class="text-gray-500 text-theme-xs dark:text-gray-400"> Media </span>
                        <span class="inline-block w-1 h-1 bg-gray-400 rounded-full"></span>
                        <span class="text-gray-500 text-theme-xs dark:text-gray-400">
                          Download
                        </span>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Simplebar>
          <!-- ====== Inbox Details Box End -->

          <div
            class="sticky bottom-0 border-t border-gray-200 bg-white p-4 rounded-b-2xl dark:border-gray-800 dark:bg-[#171f2f]"
          >
            <div class="flex items-center gap-3">
              <button
                class="flex items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-500 shadow-theme-xs hover:bg-gray-50 hover:text-gray-800 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200"
              >
                <svg
                  class="stroke-current"
                  width="20"
                  height="20"
                  viewBox="0 0 20 20"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M8.12501 2.2915L2.29167 8.12484L8.12501 13.9582V10.1467C12.7241 10.1467 16.5665 13.3864 17.4947 17.7082C17.6347 17.0564 17.7084 16.3799 17.7084 15.6863C17.7084 10.3936 13.4177 6.10295 8.12501 6.10295V2.2915Z"
                    stroke=""
                    stroke-width="1.5"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                </svg>

                Reply
              </button>

              <button
                class="flex items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-500 shadow-theme-xs hover:bg-gray-50 hover:text-gray-800 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200"
              >
                <svg
                  class="fill-current"
                  width="20"
                  height="20"
                  viewBox="0 0 20 20"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    d="M9.47571 3.2734C9.69021 3.0589 10.0128 2.99474 10.2931 3.11082C10.5733 3.22691 10.756 3.50039 10.756 3.80373V6.1504C15.0735 6.52995 18.4597 10.1551 18.4597 14.5712C18.4597 15.182 18.3947 15.7786 18.2712 16.354C18.1969 16.6996 17.8914 16.9465 17.5379 16.9465C17.1844 16.9465 16.8788 16.6996 16.8046 16.354C16.1823 13.4565 13.7537 11.2297 10.756 10.9082V13.182C10.756 13.4854 10.5733 13.7589 10.2931 13.875C10.0128 13.991 9.69021 13.9269 9.47571 13.7124L4.78655 9.02322C4.6459 8.88256 4.56688 8.6918 4.56688 8.49289C4.56688 8.29397 4.6459 8.10321 4.78655 7.96256L9.47571 3.2734ZM9.25604 6.86758V5.61439L6.37754 8.49289L9.25604 11.3714V10.1182C9.25604 9.70395 9.59183 9.36817 10.006 9.36817C12.7248 9.36817 15.1431 10.6513 16.6894 12.6448C15.854 9.7415 13.1781 7.61758 10.006 7.61758C9.59183 7.61758 9.25604 7.2818 9.25604 6.86758ZM5.93258 3.27338C6.22548 2.98049 6.70035 2.98049 6.99324 3.27338C7.28613 3.56628 7.28613 4.04115 6.99324 4.33404L3.36474 7.96254C3.07185 8.25543 3.07185 8.73031 3.36474 9.0232L6.99324 12.6517C7.28613 12.9446 7.28613 13.4195 6.99324 13.7124C6.70035 14.0052 6.22548 14.0052 5.93258 13.7124L2.30408 10.0839C1.42541 9.20518 1.42541 7.78056 2.30408 6.90188L5.93258 3.27338Z"
                    fill=""
                  />
                </svg>

                Reply all
              </button>

              <button
                class="flex items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm font-medium text-gray-500 shadow-theme-xs hover:bg-gray-50 hover:text-gray-800 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03] dark:hover:text-gray-200"
              >
                <svg
                  class="stroke-current"
                  width="20"
                  height="20"
                  viewBox="0 0 20 20"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M11.875 2.2915L17.7083 8.12484L11.875 13.9582V10.1467C7.2759 10.1467 3.43348 13.3864 2.50533 17.7082C2.36535 17.0564 2.29166 16.3799 2.29166 15.6863C2.29166 10.3936 6.58227 6.10295 11.875 6.10295V2.2915Z"
                    stroke=""
                    stroke-width="1.5"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                  />
                </svg>

                Forward
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Inbox Mailbox End -->
    </div>
  </div>
</template>

<script setup>
import EmailSidebar from './EmailSidebar.vue'
import Simplebar from 'simplebar-vue'
</script>
