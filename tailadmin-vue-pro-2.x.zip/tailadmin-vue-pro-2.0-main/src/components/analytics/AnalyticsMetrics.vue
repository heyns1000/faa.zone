<template>
  <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 md:gap-6 xl:grid-cols-4">
    <!-- Metric Item Start -->
    <div
      class="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03]"
    >
      <p class="text-gray-500 text-theme-sm dark:text-gray-400">Unique Visitors</p>

      <div class="flex items-end justify-between mt-3">
        <div>
          <h4 class="text-2xl font-bold text-gray-800 dark:text-white/90">24.7K</h4>
        </div>

        <div class="flex items-center gap-1">
          <span
            class="flex items-center gap-1 rounded-full bg-success-50 px-2 py-0.5 text-theme-xs font-medium text-success-600 dark:bg-success-500/15 dark:text-success-500"
          >
            +20%
          </span>

          <span class="text-gray-500 text-theme-xs dark:text-gray-400"> Vs last month </span>
        </div>
      </div>
    </div>
    <!-- Metric Item End -->

    <!-- Metric Item Start -->
    <div
      class="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03]"
    >
      <p class="text-gray-500 text-theme-sm dark:text-gray-400">Total Pageviews</p>

      <div class="flex items-end justify-between mt-3">
        <div>
          <h4 class="text-2xl font-bold text-gray-800 dark:text-white/90">55.9K</h4>
        </div>

        <div class="flex items-center gap-1">
          <span
            class="flex items-center gap-1 rounded-full bg-success-50 px-2 py-0.5 text-theme-xs font-medium text-success-600 dark:bg-success-500/15 dark:text-success-500"
          >
            +4%
          </span>

          <span class="text-gray-500 text-theme-xs dark:text-gray-400"> Vs last month </span>
        </div>
      </div>
    </div>
    <!-- Metric Item End -->

    <!-- Metric Item Start -->
    <div
      class="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03]"
    >
      <p class="text-gray-500 text-theme-sm dark:text-gray-400">Bounce Rate</p>

      <div class="flex items-end justify-between mt-3">
        <div>
          <h4 class="text-2xl font-bold text-gray-800 dark:text-white/90">54%</h4>
        </div>

        <div class="flex items-center gap-1">
          <span
            class="flex items-center gap-1 rounded-full bg-error-50 px-2 py-0.5 text-theme-xs font-medium text-error-600 dark:bg-error-500/15 dark:text-error-500"
          >
            -1.59%
          </span>

          <span class="text-gray-500 text-theme-xs dark:text-gray-400"> Vs last month </span>
        </div>
      </div>
    </div>
    <!-- Metric Item End -->

    <!-- Metric Item Start -->
    <div
      class="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03]"
    >
      <p class="text-gray-500 text-theme-sm dark:text-gray-400">Visit Duration</p>

      <div class="flex items-end justify-between mt-3">
        <div>
          <h4 class="text-2xl font-bold text-gray-800 dark:text-white/90">2m 56s</h4>
        </div>

        <div class="flex items-center gap-1">
          <span
            class="flex items-center gap-1 rounded-full bg-success-50 px-2 py-0.5 text-theme-xs font-medium text-success-600 dark:bg-success-500/15 dark:text-success-500"
          >
            +7%
          </span>

          <span class="text-gray-500 text-theme-xs dark:text-gray-400"> Vs last month </span>
        </div>
      </div>
    </div>
    <!-- Metric Item End -->
  </div>
</template>

<script></script>
