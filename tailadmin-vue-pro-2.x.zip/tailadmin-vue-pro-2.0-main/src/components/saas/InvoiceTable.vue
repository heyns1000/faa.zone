<template>
  <div
    class="rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-white/[0.03]"
  >
    <div class="px-6 py-4">
      <h3 class="text-lg font-semibold text-gray-800 dark:text-white/90">Recent Invoices</h3>
    </div>
    <div class="custom-scrollbar overflow-x-auto">
      <table class="min-w-full">
        <thead>
          <tr class="bg-gray-50 dark:bg-gray-900">
            <th
              class="px-6 py-4 text-left text-sm font-medium whitespace-nowrap text-gray-500 dark:text-gray-400"
            >
              Serial No:
            </th>
            <th
              class="px-6 py-4 text-left text-sm font-medium whitespace-nowrap text-gray-500 dark:text-gray-400"
            >
              Close Date
            </th>
            <th
              class="px-6 py-4 text-left text-sm font-medium whitespace-nowrap text-gray-500 dark:text-gray-400"
            >
              User
            </th>
            <th
              class="px-6 py-4 text-left text-sm font-medium whitespace-nowrap text-gray-500 dark:text-gray-400"
            >
              Amount
            </th>
            <th
              class="px-6 py-4 text-left text-sm font-medium whitespace-nowrap text-gray-500 dark:text-gray-400"
            >
              Status
            </th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-200 dark:divide-gray-800">
          <tr>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              #DF429
            </td>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              April 28, 2016
            </td>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              Jenny Wilson
            </td>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              $473.85
            </td>
            <td class="px-6 py-4 text-left">
              <span
                class="bg-success-50 text-theme-xs text-success-600 dark:bg-success-500/15 dark:text-success-500 rounded-full px-2 py-0.5 font-medium"
              >
                Complete
              </span>
            </td>
          </tr>
          <tr>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              #HTY274
            </td>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              October 30, 2017
            </td>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              Wade Warren
            </td>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              $293.01
            </td>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              <span
                class="bg-success-50 text-theme-xs text-success-600 dark:bg-success-500/15 dark:text-success-500 rounded-full px-2 py-0.5 font-medium"
              >
                Complete
              </span>
            </td>
          </tr>
          <tr>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              #LKE600
            </td>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              May 29, 2017
            </td>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              Darlene Robertson
            </td>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              $782.01
            </td>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              <span
                class="bg-warning-50 text-theme-xs text-warning-600 dark:bg-warning-500/15 dark:text-warning-500 rounded-full px-2 py-0.5 font-medium"
              >
                Pending
              </span>
            </td>
          </tr>
          <tr>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              #HRP447
            </td>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              May 20, 2015
            </td>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              Arlene McCoy
            </td>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              $202.87
            </td>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              <span
                class="bg-error-50 text-theme-xs text-error-600 dark:bg-error-500/15 dark:text-error-500 rounded-full px-2 py-0.5 font-medium"
              >
                Cancelled
              </span>
            </td>
          </tr>
          <tr>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              #WRH647
            </td>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              March 13, 2014
            </td>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              Bessie Cooper
            </td>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              $490.51
            </td>
            <td
              class="px-6 py-4 text-left text-sm whitespace-nowrap text-gray-700 dark:text-gray-400"
            >
              <span
                class="bg-success-50 text-theme-xs text-success-600 dark:bg-success-500/15 dark:text-success-500 rounded-full px-2 py-0.5 font-medium"
              >
                Complete
              </span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>
