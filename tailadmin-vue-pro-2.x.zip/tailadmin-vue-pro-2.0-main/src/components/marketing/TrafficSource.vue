<template>
  <div
    class="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-white/[0.03] sm:p-6"
  >
    <div class="flex items-center justify-between gap-2 mb-6">
      <div>
        <h3 class="text-lg font-semibold text-gray-800 dark:text-white/90">Top Traffic Source</h3>
      </div>

      <div class="relative"></div>
    </div>

    <div>
      <div
        class="flex items-center justify-between py-3 border-b border-gray-100 last:border-b-0 dark:border-gray-800"
      >
        <div class="flex items-center gap-4">
          <div class="items-center w-full rounded-full max-w-8">
            <img src="/images/brand/brand-05.svg" alt="brand" />
          </div>
          <div>
            <p class="font-medium text-gray-700 text-theme-sm dark:text-gray-300">Google</p>
          </div>
        </div>

        <div class="flex w-full max-w-[140px] items-center gap-3">
          <div class="relative block h-2 w-full max-w-[100px] rounded-sm bg-gray-200 dark:bg-gray-800">
            <div
              class="absolute left-0 top-0 flex h-full w-[79%] items-center justify-center rounded-sm bg-brand-500 text-xs font-medium text-white"
            ></div>
          </div>
          <p class="font-medium text-gray-700 text-theme-sm dark:text-gray-400">79%</p>
        </div>
      </div>

      <div
        class="flex items-center justify-between py-3 border-b border-gray-100 last:border-b-0 dark:border-gray-800"
      >
        <div class="flex items-center gap-4">
          <div class="items-center w-full rounded-full max-w-8">
            <img src="/images/brand/brand-06.svg" alt="brand" />
          </div>
          <div>
            <p class="font-medium text-gray-700 text-theme-sm dark:text-gray-300">Youtube</p>
          </div>
        </div>

        <div class="flex w-full max-w-[140px] items-center gap-3">
          <div class="relative block h-2 w-full max-w-[100px] rounded-sm bg-gray-200 dark:bg-gray-800">
            <div
              class="absolute left-0 top-0 flex h-full w-[55%] items-center justify-center rounded-sm bg-brand-500 text-xs font-medium text-white"
            ></div>
          </div>
          <p class="font-medium text-gray-700 text-theme-sm dark:text-gray-400">55%</p>
        </div>
      </div>

      <div
        class="flex items-center justify-between py-3 border-b border-gray-100 last:border-b-0 dark:border-gray-800"
      >
        <div class="flex items-center gap-4">
          <div class="items-center w-full rounded-full max-w-8">
            <img src="/images/brand/brand-02.svg" alt="brand" />
          </div>
          <div>
            <p class="font-medium text-gray-700 text-theme-sm dark:text-gray-300">Facebook</p>
          </div>
        </div>

        <div class="flex w-full max-w-[140px] items-center gap-3">
          <div class="relative block h-2 w-full max-w-[100px] rounded-sm bg-gray-200 dark:bg-gray-800">
            <div
              class="absolute left-0 top-0 flex h-full w-[48%] items-center justify-center rounded-sm bg-brand-500 text-xs font-medium text-white"
            ></div>
          </div>
          <p class="font-medium text-gray-700 text-theme-sm dark:text-gray-400">48%</p>
        </div>
      </div>

      <div
        class="flex items-center justify-between py-3 border-b border-gray-100 last:border-b-0 dark:border-gray-800"
      >
        <div class="flex items-center gap-4">
          <div class="items-center w-full rounded-full max-w-8">
            <img src="/images/brand/brand-04.svg" alt="brand" />
          </div>
          <div>
            <p class="font-medium text-gray-700 text-theme-sm dark:text-gray-300">Instagram</p>
          </div>
        </div>

        <div class="flex w-full max-w-[140px] items-center gap-3">
          <div class="relative block h-2 w-full max-w-[100px] rounded-sm bg-gray-200 dark:bg-gray-800">
            <div
              class="absolute left-0 top-0 flex h-full w-[48%] items-center justify-center rounded-sm bg-brand-500 text-xs font-medium text-white"
            ></div>
          </div>
          <p class="font-medium text-gray-700 text-theme-sm dark:text-gray-400">48%</p>
        </div>
      </div>
    </div>

    <a
      href="#"
      class="mt-6 flex items-center justify-center gap-2 rounded-lg border border-gray-300 bg-white p-2.5 text-theme-sm font-medium text-gray-700 shadow-theme-xs hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-400 dark:hover:bg-white/[0.03]"
    >
      View All
    </a>
  </div>
</template>

<script>
export default {}
</script>

<style></style>
