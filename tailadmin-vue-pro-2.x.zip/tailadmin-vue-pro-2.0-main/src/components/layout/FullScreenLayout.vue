<template>
  <div class="min-h-screen">
    <main>
      <slot></slot>
    </main>
  </div>
</template>

<script setup lang="ts"></script>
